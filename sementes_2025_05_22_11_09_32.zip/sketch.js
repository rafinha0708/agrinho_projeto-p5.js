let sementes = [];
let tempo = 30;
let pontos = 0;
let tempoInicio;
let estadoJogo = "inicial"; // Pode ser 'inicial', 'jogando', 'fim'
let intervaloDeEspaco = 50; // Distância mínima entre as sementes

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  tempoInicio = millis();
  frameRate(60); // Garantir que o jogo tenha uma taxa de atualização constante
}

function draw() {
  background(200, 255, 200); // Cor do fundo representando o campo

  // Exibir o tempo restante
  let tempoRestante = max(0, tempo - floor((millis() - tempoInicio) / 1000));
  textSize(24);
  fill(0);
  text("Tempo: " + tempoRestante, width / 2, 30);

  // Exibir a pontuação
  textSize(24);
  text("Pontos: " + pontos, width / 2, 60);

  // Se o jogo estiver em "jogando"
  if (estadoJogo === "jogando") {
    for (let i = 0; i < sementes.length; i++) {
      sementes[i].mostrar();
    }

    // Verifica o tempo restante e termina o jogo quando acaba
    if (tempoRestante <= 0) {
      estadoJogo = "fim";
      gameOver();
    }
  }

  // Tela inicial
  if (estadoJogo === "inicial") {
    fill(0);
    textSize(32);
    text("Plante as sementes corretamente!", width / 2, height / 2 - 40);
    textSize(20);
    text("Pressione ENTER para começar", width / 2, height / 2 + 40);
  }

  // Tela de fim de jogo
  if (estadoJogo === "fim") {
    fill(0);
    textSize(32);
    text("Fim de Jogo!", width / 2, height / 2 - 40);
    textSize(24);
    text("Sua pontuação: " + pontos, width / 2, height / 2 + 40);
    text("Pressione 'R' para reiniciar", width / 2, height / 2 + 80);
  }
}

// Função para iniciar o jogo
function keyPressed() {
  if (keyCode === ENTER && estadoJogo === "inicial") {
    estadoJogo = "jogando";
    tempoInicio = millis(); // Reiniciar o tempo
    sementes = []; // Limpar sementes anteriores
    pontos = 0;
    loop(); // Iniciar o loop de atualização
  }

  // Reiniciar o jogo
  if (keyCode === 82 && estadoJogo === "fim") { // 'R' para reiniciar
    estadoJogo = "inicial";
    sementes = [];
    pontos = 0;
    loop(); // Reiniciar o loop de atualização
  }
}

// Função para plantar sementes quando o mouse é clicado
function mousePressed() {
  if (estadoJogo === "jogando") {
    let semente = new Semente(mouseX, mouseY);
    sementes.push(semente);
    // Verificar e atualizar os pontos ao plantar a semente
    verificarSemente(semente);
  }
}

function verificarSemente(semente) {
  let pontosAdicionados = 0;

  // Verificar se a semente foi plantada dentro do campo válido
  if (semente.x > width * 0.1 && semente.x < width * 0.9 && semente.y > height * 0.1 && semente.y < height * 0.9) {
    pontosAdicionados += 10; // 10 pontos para uma semente plantada corretamente dentro do campo

    // Verificar a distância mínima entre as sementes
    for (let i = 0; i < sementes.length - 1; i++) {
      if (dist(semente.x, semente.y, sementes[i].x, sementes[i].y) < intervaloDeEspaco) {
        pontosAdicionados -= 5; // Penalidade de 5 pontos se as sementes estiverem muito próximas
      }
    }

    // Adicionar os pontos finais após as verificações
    pontos += pontosAdicionados;
  } else {
    pontos -= 5; // Penalidade de 5 pontos se a semente for plantada fora do campo
  }
}

// Função para terminar o jogo
function gameOver() {
  noLoop(); // Parar o loop de atualização
}

class Semente {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.diameter = 15;
  }

  mostrar() {
    fill(139, 69, 19); // Cor marrom para a semente
    ellipse(this.x, this.y, this.diameter, this.diameter);
  }
}
